from flask import Flask, render_template, request  # Importing necessary modules from Flask

app = Flask(__name__)  # Creating an instance of the Flask class

# Route for the Home page
@app.route('/')
def home():
    return render_template('index.html')  # Render the 'index.html' template when the home route is accessed

# Route for the About page
@app.route('/about')
def about():
    return render_template('about.html')  # Render the 'about.html' template when the about route is accessed

# Route for the Projects page
@app.route('/projects')
def projects():
    return render_template('projects.html')  # Render the 'projects.html' template when the projects route is accessed

# Route for the Contact page with handling POST method
@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':  # If the form is submitted with POST method
        # Retrieve form data
        name = request.form['name']
        email = request.form['email']
        message = request.form['message']
        
        # Here, you can process the form data, like sending an email or storing it in a database.
        # For now, let's just print the data to the console.
        print(f"Name: {name}")
        print(f"Email: {email}")
        print(f"Message: {message}")

        # Redirect or show a success message (optional)
        return render_template('contact.html', success=True)  # Passing a success flag to show confirmation
    return render_template('contact.html')  # Render the contact form

# Run the app with debugging enabled
if __name__ == '__main__':
    app.run(debug=True)  # Start the Flask app with debug mode enabled
